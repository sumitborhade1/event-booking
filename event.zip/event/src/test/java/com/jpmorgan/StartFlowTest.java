package com.jpmorgan;

import org.junit.Test;

public class StartFlowTest {

	@Test
	public void startFlowTest() {
		
	}
}
