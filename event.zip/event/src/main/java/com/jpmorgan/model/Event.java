package com.jpmorgan.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Event implements Serializable {

	private static final long serialVersionUID = 1L;

	private String title;
	
	private LocalDateTime startTime;
	
	private LocalDateTime endTime;
	
	private String type;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Event [title=" + title + ", startTime=" + startTime + ", endTime=" + endTime + ", type=" + type + "]";
	}
}