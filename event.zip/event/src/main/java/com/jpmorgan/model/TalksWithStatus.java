package com.jpmorgan.model;

import java.util.List;

public class TalksWithStatus extends GenericStatus {

	private static final long serialVersionUID = 1L;

	private List<Talk> talksList;

	public TalksWithStatus() {
	}

	public TalksWithStatus(boolean isValid, String statusMessage, List<Talk> talksList) {
		super(isValid, statusMessage);
		this.talksList = talksList;
	}

	public List<Talk> getTalksList() {
		return talksList;
	}

	public void setTalksList(List<Talk> talksList) {
		this.talksList = talksList;
	}
}
