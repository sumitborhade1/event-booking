package com.jpmorgan.model;

import java.io.Serializable;
import java.util.List;

public class Talk implements Serializable {

	private static final long serialVersionUID = 1L;

	private String type;
	
	private String description;
	
	private List<String> tags;
	
	private String title;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "Talk [type=" + type + ", description=" + description + ", tags=" + tags + ", title=" + title + "]";
	}

}