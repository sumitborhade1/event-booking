package com.jpmorgan.model;

import java.util.Properties;

public class PropertiesWithStatus extends GenericStatus {

	private static final long serialVersionUID = 1L;
	
	private Properties properties;

	public PropertiesWithStatus() {
	}

	public PropertiesWithStatus(boolean isValid, String statusMessage, Properties properties) {
		super(isValid, statusMessage);
		this.properties = properties;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

}