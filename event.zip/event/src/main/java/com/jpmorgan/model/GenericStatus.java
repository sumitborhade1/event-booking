package com.jpmorgan.model;

import java.io.Serializable;

public class GenericStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private boolean isValid;

	private String statusMessage;

	public GenericStatus() {
	}

	public GenericStatus(boolean isValid, String statusMessage) {
		super();
		this.isValid = isValid;
		this.statusMessage = statusMessage;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

}