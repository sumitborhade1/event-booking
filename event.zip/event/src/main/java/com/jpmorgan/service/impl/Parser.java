package com.jpmorgan.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmorgan.constants.ApplicationConstants;
import com.jpmorgan.model.Talk;
import com.jpmorgan.model.Talks;
import com.jpmorgan.model.TalksWithStatus;

public class Parser {

	public static void main(String[] args) {
		String fileNameWithAbsolutePath= Parser.class.getClassLoader().getResource("talks.json").getPath();
		Parser.parse(fileNameWithAbsolutePath);
	}

	public static TalksWithStatus parse() {
		return parse("");
	}
	
	public static TalksWithStatus parse(String inputFileName) {
		boolean isValid = false;
		String validationMessage = "Initial Default setup is not successful. Please check the configurations again.";
		List<Talk> talksList = new ArrayList<Talk>();
		
		String inputFile = inputFileName;
		File inputFileObject= new File(inputFileName);
		boolean isDefaultSetup = inputFileObject != null && inputFileObject.isAbsolute();

		if (!isDefaultSetup) {
			URL url = Parser.class.getClassLoader().getResource(ApplicationConstants.INPUT_FILE);
			inputFile = url.getPath();
		}
		
		try (final InputStream fis = new FileInputStream(inputFile)) {
			ObjectMapper mapper = new ObjectMapper();
			Talks talks = mapper.readValue(fis, Talks.class);
			isValid = true;
			talksList = talks.getTalks();
		} catch (JsonParseException e) {
			//todo: handling the exception in more clearer way
			validationMessage = "Exception has occurred while parsing "+ inputFile;
		} catch (JsonMappingException e) {
			//todo: handling the exception in more clearer way
			validationMessage = "JsonMappingException has occurred while processing "+ inputFile;
		} catch (IOException e) {
			//todo: handling the exception in more clearer way
			validationMessage = "Exception has occurred while processing "+ inputFile + ". Please recheck the file.";
		} 

		TalksWithStatus talksWithStatus = new TalksWithStatus(isValid, validationMessage, talksList);
		return talksWithStatus;
	}
}