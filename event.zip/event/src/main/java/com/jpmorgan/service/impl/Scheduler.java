package com.jpmorgan.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.jpmorgan.constants.ApplicationConstants;
import com.jpmorgan.model.Event;
import com.jpmorgan.model.PropertiesWithStatus;
import com.jpmorgan.model.Talk;
import com.jpmorgan.model.Timeline;
import com.jpmorgan.utilities.GenericUtilities;

public class Scheduler {

	private Properties basicApplicationProperties;
	private List<Talk> talks;

	public Scheduler(PropertiesWithStatus basicApplicationProperties, List<Talk> talks) {
		super();
		this.basicApplicationProperties = basicApplicationProperties.getProperties();
		this.talks = talks;
	}

	public List<Timeline> generateSchedule() {
		System.out.println(talks.size());
		
		List<Timeline> list = new ArrayList<Timeline>();
		Timeline timeline = new Timeline();
		String programStartDateString = basicApplicationProperties.getProperty(ApplicationConstants.PROGRAM_START_DATE);
		String programStartTimeString = basicApplicationProperties.getProperty(ApplicationConstants.START_TIME);
		String programEndTimeString = basicApplicationProperties.getProperty(ApplicationConstants.END_TIME);
		
		String programStartDateTimeString = programStartDateString + " "+ programStartTimeString;
		
		LocalDateTime programStartDate = GenericUtilities.getStringToLocalDateTime(ApplicationConstants.DATE_TIME_FORMAT,
				programStartDateTimeString);
		
		String programEndDateTimeString = programStartDateString + " "+ programEndTimeString;
		LocalDateTime programEndDate = GenericUtilities.getStringToLocalDateTime(ApplicationConstants.DATE_TIME_FORMAT,
				programEndDateTimeString);
		
		List<Event> eventList = new ArrayList<Event>();
		
		// Lunch break
		Event lunchEvent = new Event();
		String lunchStartTimeString = programStartDateString + " " + basicApplicationProperties.getProperty(ApplicationConstants.LUNCH_START_TIME);
		LocalDateTime lunchStartDateTime = GenericUtilities.getStringToLocalDateTime(
				ApplicationConstants.DATE_TIME_FORMAT, lunchStartTimeString);

		String lunchEndTimeString = programStartDateString + " " + basicApplicationProperties.getProperty(ApplicationConstants.LUNCH_END_TIME);
		LocalDateTime lunchEndDateTime = GenericUtilities.getStringToLocalDateTime(
				ApplicationConstants.DATE_TIME_FORMAT, lunchEndTimeString);
		
		lunchEvent.setType("Lunch Break");
		lunchEvent.setStartTime(lunchStartDateTime); 
		lunchEvent.setEndTime(lunchEndDateTime);
		lunchEvent.setTitle("Lunch and networking session");
		
		eventList.add(lunchEvent);
		
		timeline.setEventList(eventList);

		List<Event> eventsList = timeline.getEventList();
		for (Event event : eventsList) {
			System.out.println(event);
		}
		
		list.add(timeline);
		return list;
	}

	public void setEvent() {

	}

	public void setLunchBreak(LocalDateTime eventTime) {

	}

	public void setTeaBreak() {

	}
}