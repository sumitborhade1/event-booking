package com.jpmorgan.service.impl;

import com.jpmorgan.model.GenericStatus;
import com.jpmorgan.model.TalksWithStatus;

public class Validator {

	public static GenericStatus validate(TalksWithStatus talksWithStatus) {
		GenericStatus genericStatus = new GenericStatus();
		
		if(!talksWithStatus.isValid()) {
			genericStatus.setStatusMessage(talksWithStatus.getStatusMessage());
			genericStatus.setValid(talksWithStatus.isValid());
		} 
		
		if (talksWithStatus.getTalksList() == null ) {
			genericStatus.setValid(false);
			genericStatus.setStatusMessage("List of task should not be null.");
		}

		return genericStatus;
	}
}