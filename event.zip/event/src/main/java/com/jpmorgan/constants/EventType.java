package com.jpmorgan.constants;

public enum EventType {

	LUNCH(1, 60),
	TEA(2, 30),
	KEYNOTE(3, 30),
	POWERPOINT(3, 60);

	private int prioirty;
	
	private int timeInMins;
	
	private EventType(int priority, int timeInMins ) {
		this.prioirty = priority;
		this.timeInMins = timeInMins;
	}

	public int getPrioirty() {
		return prioirty;
	}

	public int getTimeInMins() {
		return timeInMins;
	}
}