package com.jpmorgan.constants;

public interface ApplicationConstants {

	String EVENT_PROPERTIES = "event.properties";
	
	String INPUT_FILE = "talks.json";

	String DATE_FORMAT = "dd-MMM-yyyy";
	
	String DATE_TIME_FORMAT = "dd-MMM-yyyy HH:mm";

	String TEA_END_TIME = "tea.end.time";

	String TEA_START_TIME = "tea.start.time";

	String LUNCH_END_TIME = "lunch.end.time";

	String LUNCH_START_TIME = "lunch.start.time";

	String END_TIME = "end.time";

	String START_TIME = "start.time";

	String ONLY_WEEKDAYS = "only.weekdays";

	String PROGRAM_TOTAL_DAYS_COUNT = "program.total.days.count";

	String PROGRAM_START_DATE = "program.start.date";
}
