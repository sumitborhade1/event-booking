package com.jpmorgan;

import com.jpmorgan.model.PropertiesWithStatus;
import com.jpmorgan.model.Talks;
import com.jpmorgan.model.TalksWithStatus;
import com.jpmorgan.service.impl.Parser;
import com.jpmorgan.service.impl.Scheduler;
import com.jpmorgan.service.impl.Validator;
import com.jpmorgan.utilities.ApplicationConfigurationSetup;

public class Main {

	private static PropertiesWithStatus basicApplicationProperties;

	static {
		basicApplicationProperties = ApplicationConfigurationSetup.getBasicApplicationProperties();
		System.out.println(basicApplicationProperties.getStatusMessage());
	}

	public static void main(String[] args) {
		orchestration();
	}

	public static void orchestration() {
		// 1. Setting up initial stuff
		/*String setupFile = "C:\\Users\\sumit\\eclipse-workspace\\event\\src\\main\\resources\\event.properties";
		PropertiesWithStatus customizedProperties = ApplicationConfigurationSetup.getBasicApplicationProperties(setupFile);*/
		
		//2. Parsing the talks.json 
		TalksWithStatus talksWithStatus = Parser.parse();

		//3. Validate the inputs
		Validator.validate(talksWithStatus);
		
		Scheduler scheduler = new Scheduler(basicApplicationProperties, talksWithStatus.getTalksList());
		scheduler.generateSchedule();
	}

}