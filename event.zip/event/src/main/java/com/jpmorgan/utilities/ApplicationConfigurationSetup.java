package com.jpmorgan.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

import com.jpmorgan.constants.ApplicationConstants;
import com.jpmorgan.model.PropertiesWithStatus;
import com.jpmorgan.service.impl.Validator;

public class ApplicationConfigurationSetup {

	private static String[] REQUIRED_KEYS_ARRAY = { ApplicationConstants.PROGRAM_START_DATE,
			ApplicationConstants.PROGRAM_TOTAL_DAYS_COUNT, ApplicationConstants.ONLY_WEEKDAYS,
			ApplicationConstants.START_TIME, ApplicationConstants.END_TIME, ApplicationConstants.LUNCH_START_TIME,
			ApplicationConstants.LUNCH_END_TIME, ApplicationConstants.TEA_START_TIME,
			ApplicationConstants.TEA_END_TIME };

	public static PropertiesWithStatus getBasicApplicationProperties() {
		return getBasicApplicationProperties("");
	}

	public static PropertiesWithStatus getBasicApplicationProperties(String propertiesFileName) {
		boolean isValid = false;
		String validationMessage = "Initial Default setup is not successful. Please check the configurations again.";
		Properties properties = new Properties();

		String propertiesFile = propertiesFileName;
		File propertiesFileObject = new File(propertiesFileName);
		boolean isDefaultSetup = propertiesFileObject != null && propertiesFileObject.isAbsolute();

		if (!isDefaultSetup) {
			URL url = Validator.class.getClassLoader().getResource(ApplicationConstants.EVENT_PROPERTIES);
			propertiesFile = url.getPath();
		}

		try (final InputStream fis = new FileInputStream(propertiesFile)) {
			properties.load(fis);

			Set<Object> keySet = properties.keySet();
			Set<String> requiredKeys = Arrays.stream(REQUIRED_KEYS_ARRAY).collect(Collectors.toSet());
			Set<String> missingKeys = new HashSet<String>();
//			isValid = keySet.containsAll(requiredKeys);

			for (String requiredKey : requiredKeys) {
				if (!keySet.contains(requiredKey)) {
					missingKeys.add(requiredKey);
				}
			}

			if (missingKeys.size() > 0) {
				String missingKeysString = String.join(",", missingKeys);
				validationMessage = missingKeysString + " is/are missing in " + propertiesFile;
			} else {
				isValid = true;
				validationMessage = propertiesFile + " is valid and correctly configured.";
			}

		} catch (FileNotFoundException e) {
			// todo: handling the exception in more clearer way
			validationMessage = propertiesFile + " is not present.";
		} catch (IOException e) {
			// todo: handling the exception in more clearer way
			validationMessage = "Exception has occurred while processing " + propertiesFile
					+ ". Please recheck the configurations.";
		}

		PropertiesWithStatus propertiesWithStatus = new PropertiesWithStatus(isValid, validationMessage, properties);
		return propertiesWithStatus;
	}
}