package com.jpmorgan.utilities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GenericUtilities {

	public static LocalDate getStringToLocalDate(String format, String dateInString) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
		LocalDate localDate = LocalDate.parse(dateInString, formatter);
		return localDate;
	}
	
	public static LocalDateTime getStringToLocalDateTime(String format, String dateInString) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
		LocalDateTime localDateTime = LocalDateTime.parse(dateInString, formatter);
		return localDateTime;
	}
	
	public static void main(String[] args) {
		String date = "01-Jan-2019 12:30";
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm");
		LocalDateTime dateTime = LocalDateTime.parse(date, format);
		 
		System.out.println("origional date as string: " + date);
		System.out.println("generated LocalDateTime: " + dateTime);
	}
}
